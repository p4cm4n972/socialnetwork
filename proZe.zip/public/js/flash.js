$('.flash').textillate({loop:true,
autoStart: true});